// // Script by Branton Kunz, April 2022 - Geography 575, UW-Madison



// //begin script when window loads
// window.onload = setMap();

// //set up choropleth map
// function setMap(){
//     //use Promise.all to parallelize asynchronous data loading
//     var promises = [d3.csv("data/lab2_europe_data.csv"),                    
//                     d3.json("data/europe_base.topojson")
//                     ];    
//     Promise.all(promises).then(callback);

//     function callback(data) {
//         var csvData = data[0],
//             europe = data[1]
          
//     //translate europe TopoJSON
//     var europeCountries = topojson.feature(europe, europe.objects.EuropeCountries)

//     //examine the results
//     console.log(europeCountries);

//     }
// };



//begin script when window loads
window.onload = setMap();

//Example 1.3 line 4...set up choropleth map
function setMap() {
    //use Promise.all to parallelize asynchronous data loading
    var promises = [
        d3.csv("data/lab2_europe_data.csv"),
        d3.json("data/europe_base.topojson")
        // d3.json("data/FranceRegions.topojson"),
    ];
    Promise.all(promises).then(callback);
}

function callback(data) {
    var csvData = data[0],
        europe = data[1];
        // france = data[2];

    //translate europe TopoJSON
    var europeCountries = topojson.feature(europe, europe.objects.EuropeCountries)
        // franceRegions = topojson.feature(france, france.objects.FranceRegions);

    //examine the results
    console.log(europeCountries);
    // console.log(franceRegions);
}